"use client";

import type { Car } from "./types";
import { formatEUR, formatNumber } from "@/lib/format";
import { useAutoplayOnView } from "./useAutoplayOnView";

export function ReelCard({ car, onOpen }: { car: Car; onOpen: (car: Car) => void }) {
  const { ref } = useAutoplayOnView<HTMLVideoElement>(0.7);

  return (
    <button
      type="button"
      onClick={() => onOpen(car)}
      className="relative w-full overflow-hidden rounded-[22px] bg-black border border-white/10 aspect-[9/14] text-left"
      aria-label={`Abrir ficha de ${car.title}`}
    >
      <video
        ref={ref}
        src={car.videoUrl}
        muted
        loop
        playsInline
        preload="metadata"
        className="absolute inset-0 h-full w-full object-cover"
      />

      <div className="absolute inset-x-0 bottom-0 p-4 bg-gradient-to-t from-black/75 via-black/20 to-transparent">
        <div className="flex items-end justify-between gap-3">
          <div className="min-w-0">
            <h3 className="text-lg font-semibold leading-tight truncate">{car.title}</h3>
            <p className="text-sm text-white/85 truncate">
              {car.year} · {formatNumber(car.km)} km · {car.fuel} · {car.gearbox} · {car.eco}
            </p>
          </div>
          <div className="text-right shrink-0">
            <div className="text-lg font-bold">{formatEUR(car.price)}</div>
            {car.monthlyFrom ? (
              <div className="text-xs text-white/75">desde {formatEUR(car.monthlyFrom)}/mes</div>
            ) : null}
          </div>
        </div>

        <div className="mt-2 flex flex-wrap gap-2">
          {car.highlights.slice(0, 3).map((h) => (
            <span
              key={h}
              className="rounded-full bg-white/10 border border-white/10 px-3 py-1 text-xs text-white/90"
            >
              {h}
            </span>
          ))}
        </div>
      </div>
    </button>
  );
}
