"use client";

import { useEffect, useRef, useState } from "react";

export function useAutoplayOnView<T extends HTMLVideoElement>(threshold = 0.65) {
  const ref = useRef<T | null>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const obs = new IntersectionObserver(
      ([entry]) => setIsVisible(entry.isIntersecting),
      { threshold }
    );

    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (isVisible) el.play().catch(() => {});
    else el.pause();
  }, [isVisible]);

  return { ref, isVisible } as const;
}
