"use client";

import { buildWhatsAppUrl } from "@/lib/format";
import { WHATSAPP_PHONE } from "@/lib/demoData";

export function FloatingActions({
  onOpenFilters,
  currentCarTitle,
}: {
  onOpenFilters: () => void;
  currentCarTitle?: string;
}) {
  const msg = currentCarTitle
    ? `Hola, me interesa el coche: ${currentCarTitle}. ¿Podemos concretar una cita para verlo?`
    : "Hola, quiero información y una cita para ver un coche.";

  const href = buildWhatsAppUrl(WHATSAPP_PHONE, msg);

  return (
    <div className="fixed right-4 bottom-4 z-40 flex flex-col gap-3 safe-bottom">
      <a
        href={href}
        target="_blank"
        rel="noreferrer"
        className="rounded-full px-4 py-3 bg-emerald-500 text-black font-semibold shadow-lg shadow-emerald-500/20 border border-white/10"
      >
        WhatsApp
      </a>

      <button
        type="button"
        onClick={onOpenFilters}
        className="rounded-full px-4 py-3 bg-white/10 text-white font-semibold backdrop-blur border border-white/10"
      >
        Filtros
      </button>
    </div>
  );
}
