import { ReelFeed } from "@/components/reels/ReelFeed";
import { cars } from "@/lib/demoData";

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <header className="sticky top-0 z-40 bg-black/60 backdrop-blur border-b border-white/10">
        <div className="px-4 py-3 flex items-center justify-between">
          <div>
            <div className="text-sm text-white/70">Taller · Compra / repara / vende</div>
            <h1 className="text-lg font-semibold">Coches disponibles</h1>
          </div>
          <div className="text-xs text-white/70 text-right">
            <div>Horario: 10:00–14:00 · 16:30–20:00</div>
            <div className="hidden sm:block">Málaga</div>
          </div>
        </div>
      </header>

      <ReelFeed cars={cars} />

      <footer className="safe-bottom px-4 py-10 text-center text-white/50 text-xs border-t border-white/10">
        <p>© {new Date().getFullYear()} ReelCars. Demo.</p>
      </footer>
    </main>
  );
}
