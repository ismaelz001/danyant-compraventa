import type { Car } from "@/components/reels/types";

export const WHATSAPP_PHONE = "34XXXXXXXXX"; // TODO: pon aquí el número real SIN + (ej: 34612345678)

export const cars: Car[] = [
  {
    id: "car_001",
    title: "BMW 320d 190cv Automático",
    year: 2019,
    km: 78000,
    fuel: "Diésel",
    gearbox: "Automático",
    eco: "C",
    location: "Málaga",
    price: 23990,
    monthlyFrom: 289,
    highlights: ["1 dueño", "Historial completo", "Garantía 12 meses"],
    videoUrl: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
    images: [
      "https://images.unsplash.com/photo-1525609004556-c46c7d6cf023?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=1200&q=80&auto=format&fit=crop"
    ],
    descriptionShort: "Diésel fiable para diario, muy cuidado. Se entrega revisado.",
    descriptionLong:
      "BMW 320d automático muy cuidado. Entrega inmediata, revisión completa en taller y garantía. Ideal para quien busca consumo bajo sin renunciar a comodidad. Posibilidad de financiación (orientativa).",
    workshopNotes: ["Cambio de aceite y filtros", "Revisión frenos", "Diagnóstico completo"],
    warrantyMonths: 12
  },
  {
    id: "car_002",
    title: "SEAT León 1.5 TSI 150cv",
    year: 2018,
    km: 96000,
    fuel: "Gasolina",
    gearbox: "Manual",
    eco: "C",
    location: "Málaga",
    price: 14990,
    monthlyFrom: 199,
    highlights: ["Etiqueta C", "Revisión hecha", "Listo para entrega"],
    videoUrl: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
    images: [
      "https://images.unsplash.com/photo-1553440569-bcc63803a83d?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1511919884226-fd3cad34687c?w=1200&q=80&auto=format&fit=crop"
    ],
    descriptionShort: "Gasolina equilibrado, buen motor, mantenimiento al día.",
    descriptionLong:
      "SEAT León 1.5 TSI con buen mantenimiento. Entrega revisado con garantía. Perfecto si quieres un compacto ágil, con buen consumo y cómodo para ciudad/carretera.",
    workshopNotes: ["Neumáticos revisados", "Alineado", "Mantenimiento al día"],
    warrantyMonths: 12
  }
];
